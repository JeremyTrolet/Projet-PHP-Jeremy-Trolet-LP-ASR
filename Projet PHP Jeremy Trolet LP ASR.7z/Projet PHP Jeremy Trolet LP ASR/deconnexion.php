<?php

setcookie('sid', '', -1); //Cette ligne a pour but de définir un cookie
                         //Ce cookie sera envoyé avec le reste des en-têtes HTTP

header("Location: index.php");
exit();

?>
