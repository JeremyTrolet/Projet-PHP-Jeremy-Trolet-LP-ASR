<?php

require_once 'config/init.conf.php' ;//Cette fonction a un rôle identique a require excepté que PHP va vérifier si le fichier a déjà été inclus
                                     //Si oui, il ne sera pas inclus une seconce fois
require_once('libs/Smarty.class.php') ;

$smarty = new Smarty();

$smarty->setTemplateDir('templates/') ;
$smarty->setCompileDir('templates_c/') ;

/* $smarty->setConfigDir('/web/www.example.com/guestbook/configs/'); */ 
/* $smarty->setCacheDir('/web/www.example.com/guestbook/cache/'); */ 

$prenom = ' Jeremy ' ;
$smarty->assign('prenom', $prenom) ;

//** un-comment the following line to show the debug console
$smarty->debugging = true ;

$smarty->display('smarty-test.tpl') ;

?>
