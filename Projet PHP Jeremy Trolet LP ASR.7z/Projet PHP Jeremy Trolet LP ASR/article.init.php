<?php
require_once 'config/init.conf.php';//Cette fonction a un rôle identique a require excepté que PHP va vérifier si le fichier a déjà été inclus
                                     //Si oui, il ne sera pas inclus une seconce fois
require_once 'include/fonctions.inc.php';
require_once 'config/bdd.conf.php';
require_once 'config/connexion.conf.php';
include_once 'include/header.inc.php';
// toujours mettre dans cet ordre // 

if(!empty(filter_input(INPUT_POST, 'submit'))){ // Lorsqu'on appuie sur le bouton de soumission du formulaire
    //print_r2(filter_input_array(INPUT_POST)); 
    //print_r2(filter_input_array(INPUT_POST));
    
    $titre = filter_input(INPUT_POST, 'titre');
    $texte = filter_input(INPUT_POST, 'texte');
    
    $publie = isset($_POST['publie']) ? 1 : 0; 
    // Cette ligne est une condition ternaire qui a pour but que si la checkbox de publie est cochée alors publie se verran affecter la valeur 1 
    
	
	
	
	
	
	
	
	
	
	