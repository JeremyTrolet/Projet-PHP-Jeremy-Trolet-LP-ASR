<?php
/* Smarty version 3.1.34-dev-7, created on 2019-12-20 13:49:50
  from 'C:\wamp64\www\blog\templates\smarty-test.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5dfcc36e147af7_51306225',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '26913f49bbd40db03363f7dce1ae35391726b1b9' => 
    array (
      0 => 'C:\\wamp64\\www\\blog\\templates\\smarty-test.tpl',
      1 => 1576846158,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dfcc36e147af7_51306225 (Smarty_Internal_Template $_smarty_tpl) {
?><h1>Mon prénom est <?php echo $_smarty_tpl->tpl_vars['prenom']->value;?>
</h1><?php }
}
