<?php
$connecte = FALSE;
if(isset($_COOKIE['id'])) {
    $sid = $_COOKIE['id'];
    $sth_connexion = $bdd->prepare("SELECT * "
            . "FROM user "
            . "WHERE id = :id");
    $sth_connexion->bindValue(':id', $sid, PDO::PARAM_STR);
    $sth_connexion->execute();
    if($sth_connexion->rowCount() > 0) {
        $connecte = TRUE;
    }
}