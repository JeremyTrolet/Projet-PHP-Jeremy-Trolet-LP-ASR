<?php

require_once 'config/init.conf.php'; //Cette fonction a un rôle identique a require excepté que PHP va vérifier si le fichier a déjà été inclus
                                     //Si oui, il ne sera pas inclus une seconce fois
require_once 'include/fonctions.inc.php';
require_once 'config/bdd.conf.php';
include_once 'include/header.inc.php';
// toujours mettre dans cet ordre // 
// 
// Déclaration d'un tableau vide
  $tableau = array( "id" => "",
                    "titre" => "",
                    "texte" => "",
                    "publie" => "",
                    "date" => "" 
 ); 
  
echo $tableau[id]; // Affiche ID
echo $tableau[titre]; // Affiche Titre
echo $tableau[texte]; // Affiche Texte
echo $tableau[publie]; // Affiche Publie
echo $tableau[date]; // Affiche Date 


       



if (!empty($_POST['submit'])) {
    
    print_r2($_POST);
    print_r2($_FILES);

    $Article = $_POST['Article'];
    $texte = $_POST['texte'];

    $publie = isset($_POST['publie']) ? 1 : 0;

    if (isset($_POST['publie'])) {
        $publie = 1; 
    } else {
        $publie = 0;
    }

    $date = date('Y-m-d');
//echo $date;

    /* @var $bdd PDO */
    $sth = $bdd->prepare("INSERT INTO articles "
            . "(titre, texte, publie, date) "
            . " VALUES (:titre, :texte, :publie, :date)");
    $sth->bindValue(':titre', $titre, PDO::PARAM_STR);
    $sth->bindValue(':texte', $texte, PDO::PARAM_STR);
    $sth->bindValue(':publie', $publie, PDO::PARAM_STR);
    $sth->bindValue(':date', $date, PDO::PARAM_STR);

    $sth->execute();

    $id_article = $bdd->lastInsertId();

    if ($_FILES['img']['error'] == 0) {
        move_uploaded_file($_FILES['img']['tmp_name'], 'img/' . $id_article . '.jpg');
    }
    
    /*
      
      
      $_SESSION['notification']['message'] = '<b>Félicitations</b>, votre <u>article</u> est ajouté ! '

     */ 
     
    $_SESSION['notification']['result'] = TRUE;    
     
    
    
    header("Location: index.php"); /*  */
    exit(); /* permet de mettre fin au script */
    
    /*

      if(!isset $_POST['envoyer']) /* isset permet de savoir si une variable existe
      {
      ...
      } 
      ...

     */
}



?>
<!-- Page Content -->
<div class="container">
    <div class="row">
    </div>
    <form method="POST" action="article.php" enctype="multipart/form-data">
        <div class="form-group">
            <label for="article">Article</label>
            <input type="text" class="form-control" id="titre" placeholder="" name="Titre">
        </div>
        <div class="form-group">
            <label for="Contenu de l'article">Texte</label>
            <input type="texte" class="form-control" id="texte" placeholder="Texte">
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

</div>
</div>
<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.slim.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body 

</html>

