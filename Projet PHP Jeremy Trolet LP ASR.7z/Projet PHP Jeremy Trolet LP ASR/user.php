<?php
require_once 'config/init.conf.php';//Cette fonction a un rôle identique a require excepté que PHP va vérifier si le fichier a déjà été inclus
                                     //Si oui, il ne sera pas inclus une seconce fois
require_once 'include/fonctions.inc.php';
require_once 'config/bdd.conf.php';
require_once 'config/connexion.conf.php';
include_once 'include/header.inc.php';
// toujours mettre dans cet ordre // 
/* @var $bdd PDO */

if(!empty(filter_input(INPUT_POST, 'submit'))){ //si le bouton de soummision de formulaire a été validé dans ce cas
    //print_r2(filter_input_array(INPUT_POST));
    //print_r2(filter_input_array(INPUT_POST));
    
    $nom = filter_input(INPUT_POST, 'nom');
    $prenom = filter_input(INPUT_POST, 'prenom');
    $email = filter_input(INPUT_POST, 'email');
    $mdp = sha1(filter_input(INPUT_POST, 'mdp'));//Le mot de passe est crypté
    
    $sth = $bdd->prepare("INSERT INTO user " //Préparation de la requête d'insertion de l'article dans la BDD 
            . "(nom, prenom, email, mdp) "
            . "VALUES (:nom, :prenom, :email, :mdp)");
    $sth->bindValue(':nom', $nom, PDO::PARAM_STR);
    $sth->bindValue(':prenom', $prenom, PDO::PARAM_STR);
    $sth->bindValue(':email', $email, PDO::PARAM_STR);
    $sth->bindValue(':mdp', $mdp, PDO::PARAM_STR);
    
    $sth->execute(); //Execution de la requête préparée
    // true sera retournée si l'éxécution s'est bien déroulée
    // dans le cas contraire erreur sera retournéretourne
    
    //$id_user = $bdd->lastInsertId(); //Récuperation et affectation à $id_user le dernier id inseré dans la BDD
    
    $message = '<b>Félicitations</b>, votre compte a été créé !'; //Une notification s'affiche sur la page d'accueil quand un article s'est bien ajouté à la BDD
    $result = 'success'; //Permet de savoir comment s'est déroulé l'envoi de l'article savoir
    
    declareNotification($message, $result); 
    
    header("Location: index.php"); //on redirige l'utilisateur à la page d'accueil lorsqu'il a inséré un article.
    
    exit();//fin de l'exécution du script
}
?>

<!-- Page Content -->
<div class="container">
    <div class="row">
        <div class="col-lg-12 text-center">
            <h1 class="mt-5">Inscription d'un utilisateur</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <form method="POST" action="user.php" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="nom">Votre nom</label>
                    <input type="text" required class="form-control" id="nom" name="nom">
                </div>
                <div class="form-group">
                    <label for="prenom">Votre prénom</label>
                    <input type="text" required class="form-control" id="prenom" name="prenom">
                </div>
                <div class="form-group">
                    <label for="email">Votre adresse mail</label>
                    <input type="email" required class="form-control" id="email" name="email" placeholder="example@gmail.com">
                </div>
                <div class="form-group">
                    <label for="mdp">Votre mot de passe</label>
                    <input type="password" required class="form-control" id="texte" rows="3" name="mdp" placeholder="Entrer ici votre mot de passe">
                </div>
                <button type="submit" class="btn btn-primary" name="submit" value="bouton">Inscription</button>
            </form>
        </div>
    </div>


</div>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.slim.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>