<?php
require_once 'config/init.conf.php'; //Cette fonction a un rôle identique a require excepté que PHP va vérifier si le fichier a déjà été inclus
                                     //Si oui, il ne sera pas inclus une seconce fois
require_once 'include/fonctions.inc.php';
require_once 'config/bdd.conf.php';
require_once('libs/Smarty.class.php') ;
include_once 'include/header.inc.php';
// toujours mettre dans cet ordre // 

// @var $bdd PDO ==> indique a PDO que $bdd est un objet de type PDO //
//print_r2($_SESSION); // 
//print_r2($_GET); //

$page_courante = !empty($_GET['p']) ? $_GET['p'] : 1; 
//si p n'est vide il prendra donc la valeur attribuée à $_GET['p'] 
// Dans le cas contraite il prendra la valeur 1

$nb_total_articles = countArticles($bdd);
//var_dump($nb_total_articles);

$index_depart = returnIndex($page_courante, _nb_articles_par_page_);
//var_dump($index_depart);

$nb_total_pages = ceil($nb_total_articles / _nb_articles_par_page_); //ceil arrondit au nombre supérieur, floor() fait l'inverse
//var_dump($nb_total_pages);

$sth = $bdd->prepare("SELECT id," 
        . "titre, "
        . "texte,"
        . "DATE_FORMAT(date, '%d/%m/%Y') AS date_fr, "
        . "publie "
        . "WHERE publie = :publie "
        . "LIMIT :index_depart, :nb_articles_par_page");
$sth->bindValue("publie", 1,PDO::PARAM_BOOL);
$sth->bindValue("index_depart", $index_depart, PDO::PARAM_INT);
$sth->bindValue(":nb_articles_par_page", _nb_articles_par_page_, PDO::PARAM);
$sth->execute(); //Execute la requête qui a été préparée 

/* $sth = $bdd->prepare("SELECT *"
        . "FROM articles "
        . "WHERE publie = :publie");
$sth->bindValue(":publie", 1, PDO::PARAM_BOOL);
$sth->execute();

$tab_result = $sth->fetchAll(PDO::FETCH_ASSOC);
/* echo $tab_result[0]['titre']; ==> permet d'afficher le 1er titre */

/* $index_depart = returnIndex($page_courante, _nb_articles_par_page_);
var_dump($index_depart); */ 

$tab_result = $sth->fetchAll(PDO::FETCH_ASSOC);     

// print_r2($tab_result); /* print r2 affiche le résultat d'un tableau */

$smarty = new Smarty();

$smarty->setTemplateDir('templates/') ;
$smarty->setCompileDir('templates_c/') ;

/* $smarty->setConfigDir('/web/www.example.com/guestbook/configs/'); */ 
/* $smarty->setCacheDir('/web/www.example.com/guestbook/cache/'); */ 

$smarty->assign('tab_result', $tab_result) ;

//** un-comment the following line to show the debug console
$smarty->debugging = true ;

$smarty->display('index.tpl') ; 

?>

<!-- Page Content -->
<div class="container"> 
    <div class="row">
        <div class="col-lg-12 text-center">
            <h1 class="mt-5">Liste articles publiés</h1>
            <p class="lead">Bonne lecture</p>
            <ul class="list-unstyled">
                <li>Bootstrap 4.3.1</li>
                <li>jQuery 3.4.1</li>
            </ul>
        </div>
    </div>  
    <?php 
    if (isset($_SESSION['notification'])) {
        ?>
        <div class="row">
            <div class="col-12">
                <div class="alert alert-<?= $_SESSION['notification']['result'] ?> alert-dismissible fade show" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <?= $_SESSION['notification']['message'] ?>
                    <?php unset($_SESSION['notification']) ?>
                </div>
            </div>
        </div>
        <?php
    }
    ?>
    <div class="row">
        <?php
        foreach ($tab_result as $key => $value) { //  Cette ligne a pour but de passer en revue le tableau $tab_result
            // Lors de chaque itération la valeur de l'élément est affectée à $value, le pointeur interne du tableau avance d'un élément
            // La seconde forme affecte la clé de l'élément à la variable $key lors de chaque itération
        }
            ?>
            <div class="col-6"> 
                <div class="card" style=""width: 100%;">
     <img class="card-img-top" src="img/<?= $value['id']; ?>.jpg" alt="<?= $value['titre']; ?>">
                   <div class="card-body">
                        <h5 class="card-title"><?= $value['titre']; ?></h5>
                        <p class="card-text"><?= $value['texte']; ?></p>
                        <a href="#" class="btn btn-primary"><?= $value['date']; ?></a>
                        <?php 
                        if($connecte == true){ ?>
                        <a href="article.php?id=<?= $value['id']; ?>&action=modifier" class="btn btn-primary">Modifier</a>
                        <?php } ?>
  </div>
                </div>
            </div>
            <?php
        }
        ?>
    </div>

</div>
<div class="row">
    <div class="col-12">
        <nav>
            <ul class="pagination pagination-lg">
                <?php
                        for ($index = 1; $index <= $nb_total_pages; $index++) {
                            $active = $page_courante == $index ? 'active' : '';
                ?>
                <li class="page-item <?= $active ?>"><a class="page-link" href="?p=<?= $index ?>"><?= $index ?> </a></li>
                <?php
                        }
                ?>
            </ul>
        </nav>
    </div>

</div>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.slim.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>