<?php
try {
    $bdd = new PDO('mysql:host=localhost;dbname=myblog;charset=utf8', 'root', 'bruh'); // Réalise la connexion à la BDD
    $bdd->exec("set names utf8");// Sert à mettre les noms en encodage utf8
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Cette ligne sert à configurer le rapport d'erreur en émissions d'exceptions
} catch (Exception $ex) {
    die('Erreur : '. $ex->getMessage());
}

