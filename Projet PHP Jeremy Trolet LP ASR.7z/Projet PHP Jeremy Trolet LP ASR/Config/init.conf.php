<?php

session_start(); // Cette ligne a pour but de lancer la session

// Affiche erreurs et avertissements PHP
error_reporting(E_ALL); //Fixe le niveau de rapport d'erreurs PHP
ini_set("display_errors",1);//Change la valeur de l'option de configuration varname 
// Cela va lui affecter la valeur de newvalue 
// La valeur de l'option de configuration sera modifiée durant l'exécution du script 
// Reprends sa valeur par défaut lorsque l'éxecution du script est terminée  

define('_nb_articles_par_page_', 2); // Définition de la constante _nb_articles_par_pages qui a pour valeur 2

date_default_timezone_set('Europe/Paris');//Définit le fuseau horaire utilisé dans le projet pour les dates 

?> 